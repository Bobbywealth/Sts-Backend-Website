<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="wrapper">
 <div class="content">
   <div class="panel_s">
    <div class="panel-body">
    	<div class="col-md-12 text-center">
    		<h4><?php echo html_entity_decode($content); ?></h4>	   		    		
    	</div>
    	<br>
    	<br>
    	<br>
    	<br>
    	<div class="col-md-12 text-center">
    		<a href="javascript:history.back()" class="btn btn-primary">
    			<i class="fa fa-long-arrow-left" aria-hidden="true"></i> <?php echo _l('return_to_the_previous_page'); ?></a>
    	</div>
	  </div>
  </div>
 </div>
</div>


