<div id="commission-chart" class="hide">
   <div class="row">
     <figure class="highcharts-figure col-md-12">
       <div id="commission_chart"></div>
       
      </figure>
   </div>
</div>