<a href="<?php echo admin_url('affiliate/affiliate_program'); ?>" class="btn btn-info mbot10"><?php echo _l('new'); ?></a>
<table class="table table-affiliate-program">
  <thead>
    <th><?php echo _l('name'); ?></th>
    <th><?php echo _l('vendor'); ?></th>
    <th><?php echo _l('sale_commission'); ?></th>
    <th><?php echo _l('click_commission'); ?></th>
    <th><?php echo _l('sale_status'); ?></th>
    <th><?php echo _l('click_status'); ?></th>
    <th><?php echo _l('status'); ?></th>
    <th><?php echo _l('options'); ?></th>
  </thead>
  <tbody>
    
  </tbody>
</table>

