<table class="table table-registration-list">
  <thead>
    <th><?php echo _l('staff_dt_name'); ?></th>
    <th><?php echo _l('clients_country'); ?></th>
    <th><?php echo _l('staff_dt_email'); ?></th>
    <th><?php echo _l('username'); ?></th>
    <th><?php echo _l('staff_add_edit_phonenumber'); ?></th>
    <th><?php echo _l('referral_code'); ?></th>
    <th><?php echo _l('options'); ?></th>
  </thead>
  <tbody>
  </tbody>
</table>