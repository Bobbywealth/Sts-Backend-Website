(function($) {
	"use strict";
	initDataTable('.table-registration-list', admin_url + 'affiliate/registration_list_table');
	
})(jQuery);