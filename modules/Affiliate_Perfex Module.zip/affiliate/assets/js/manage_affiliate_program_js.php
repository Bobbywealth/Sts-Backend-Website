<script type="text/javascript">
(function($) {
	"use strict";

  	initDataTable('.table-affiliate-program', admin_url + 'affiliate/affiliate_program_table');
})(jQuery);
</script>