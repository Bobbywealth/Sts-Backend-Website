<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative customers-group-gen" style="max-height:400px;">
   <canvas id="customers-group-gen" class="animated fadeIn" height="400"></canvas>
</div>
